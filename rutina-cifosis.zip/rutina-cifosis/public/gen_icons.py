#!/usr/bin/env python3
# Script to generate icons - run once if needed
# Icons are simple colored squares with text
