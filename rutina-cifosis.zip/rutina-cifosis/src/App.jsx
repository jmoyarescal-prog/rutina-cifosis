import { useState, useEffect, useRef } from "react";

const exercises = [
  {
    id: 1,
    name: "Extensión torácica",
    subtitle: "sobre borde de silla",
    duration: 60,
    type: "timer",
    sets: 1,
    icon: "🪑",
    tip: "Coloca la zona media de la espalda en el borde. Deja caer los brazos y la cabeza hacia atrás. Respira profundo.",
  },
  {
    id: 2,
    name: "Ángel de pared",
    subtitle: "espalda pegada a la pared",
    reps: 10,
    sets: 3,
    rest: 30,
    type: "reps",
    icon: "🧍",
    tip: "Pies a 10cm de la pared. Espalda, cabeza y lumbares pegadas. Sube los brazos lentamente sin despegar nada.",
  },
  {
    id: 3,
    name: "W-Y-T en el suelo",
    subtitle: "boca abajo, 3 posiciones",
    reps: 8,
    sets: 3,
    rest: 30,
    type: "reps",
    icon: "⬇️",
    tip: "Forma cada letra con tus brazos manteniendo 2-3 segundos. Aprieta los omóplatos en cada posición.",
  },
  {
    id: 4,
    name: "Bird-dog",
    subtitle: "en cuadrupedia",
    reps: 10,
    sets: 3,
    rest: 30,
    type: "reps",
    icon: "🐦",
    tip: "Extiende brazo y pierna contrarios. Mantén la espalda neutral, sin rotar la cadera. 2 seg arriba.",
  },
  {
    id: 5,
    name: "Estiramiento de pecho",
    subtitle: "en marco de puerta",
    duration: 30,
    sets: 3,
    rest: 15,
    type: "timer",
    icon: "🚪",
    tip: "Codos a 90°, antebrazos en el marco. Avanza un paso y siente la apertura. CLAVE para tu caso.",
  },
];

function formatTime(s) {
  return `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
}

function CircleTimer({ total, remaining, size = 140 }) {
  const r = 50;
  const circ = 2 * Math.PI * r;
  const progress = remaining / total;
  const offset = circ * (1 - progress);
  return (
    <svg width={size} height={size} viewBox="0 0 120 120">
      <circle cx="60" cy="60" r={r} fill="none" stroke="#1a1a1a" strokeWidth="8" />
      <circle
        cx="60" cy="60" r={r}
        fill="none"
        stroke={remaining < total * 0.3 ? "#ff3333" : "#e63030"}
        strokeWidth="8"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        strokeLinecap="round"
        transform="rotate(-90 60 60)"
        style={{ transition: "stroke-dashoffset 1s linear" }}
      />
      <text x="60" y="65" textAnchor="middle" fill="white" fontSize="22"
        fontFamily="'Courier New', monospace" fontWeight="bold">
        {formatTime(remaining)}
      </text>
    </svg>
  );
}

export default function App() {
  const [screen, setScreen] = useState("home");
  const [exIdx, setExIdx] = useState(0);
  const [setNum, setSetNum] = useState(1);
  const [phase, setPhase] = useState("ready");
  const [timeLeft, setTimeLeft] = useState(0);
  const [totalTime, setTotalTime] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const intervalRef = useRef(null);

  const ex = exercises[exIdx];
  const totalSets = ex?.sets || 1;

  function clearTimer() {
    if (intervalRef.current) clearInterval(intervalRef.current);
  }

  function startTimer(seconds, onDone) {
    clearTimer();
    setTimeLeft(seconds);
    setTotalTime(seconds);
    intervalRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearTimer();
          onDone();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  useEffect(() => {
    if (screen === "exercise") {
      const t = setInterval(() => setElapsed(e => e + 1), 1000);
      return () => clearInterval(t);
    }
  }, [screen]);

  useEffect(() => () => clearTimer(), []);

  function startExercise(idx = 0) {
    setExIdx(idx);
    setSetNum(1);
    setPhase("ready");
    setScreen("exercise");
    clearTimer();
  }

  function beginSet() {
    const cur = exercises[exIdx];
    if (cur.type === "timer") {
      setPhase("active");
      startTimer(cur.duration, () => finishSet());
    } else {
      setPhase("active");
    }
  }

  function finishSet() {
    const cur = exercises[exIdx];
    if (setNum >= cur.sets) {
      if (exIdx >= exercises.length - 1) {
        setScreen("done");
      } else {
        setExIdx(i => i + 1);
        setSetNum(1);
        setPhase("ready");
      }
    } else {
      setPhase("rest");
      startTimer(cur.rest || 30, () => {
        setSetNum(s => s + 1);
        setPhase("ready");
      });
    }
  }

  function skipRest() {
    clearTimer();
    setSetNum(s => s + 1);
    setPhase("ready");
  }

  const styles = {
    page: {
      minHeight: "100vh",
      minHeight: "100dvh",
      background: "#0d0d0d",
      display: "flex",
      flexDirection: "column",
      fontFamily: "'Courier New', monospace",
    },
    btn: {
      width: "100%",
      padding: "18px",
      background: "#e63030",
      border: "none",
      borderRadius: 4,
      color: "white",
      fontSize: 15,
      fontWeight: 900,
      letterSpacing: 3,
      textTransform: "uppercase",
      cursor: "pointer",
      WebkitTapHighlightColor: "transparent",
    },
    btnGhost: {
      width: "100%",
      padding: "14px",
      background: "transparent",
      border: "1px solid #2a2a2a",
      borderRadius: 4,
      color: "#555",
      fontSize: 12,
      letterSpacing: 3,
      textTransform: "uppercase",
      cursor: "pointer",
      marginTop: 10,
      WebkitTapHighlightColor: "transparent",
    },
  };

  // HOME
  if (screen === "home") {
    return (
      <div style={{ ...styles.page, alignItems: "center", justifyContent: "center", padding: "24px" }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 8 }}>🏠</div>
          <h1 style={{ color: "white", fontSize: 26, fontWeight: 900, letterSpacing: 2, margin: 0, textTransform: "uppercase" }}>
            Rutina Cifosis
          </h1>
          <div style={{ color: "#e63030", fontSize: 12, letterSpacing: 4, marginTop: 6, textTransform: "uppercase" }}>
            Correctiva · En Casa
          </div>
          <div style={{ color: "#444", fontSize: 12, marginTop: 10 }}>
            ~15 min · {exercises.length} ejercicios
          </div>
        </div>

        <div style={{ width: "100%", maxWidth: 380, marginBottom: 28 }}>
          {exercises.map((e, i) => (
            <div key={e.id} style={{
              display: "flex", alignItems: "center", gap: 14,
              padding: "14px 0", borderBottom: "1px solid #1a1a1a",
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: "50%",
                background: "#1a1a1a", border: "1px solid #2a2a2a",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#e63030", fontSize: 11, fontWeight: 900, flexShrink: 0,
              }}>{i + 1}</div>
              <div style={{ flex: 1 }}>
                <div style={{ color: "white", fontSize: 14, fontWeight: 700 }}>{e.name}</div>
                <div style={{ color: "#444", fontSize: 11, marginTop: 2 }}>
                  {e.type === "timer" ? `${e.sets}×${e.duration}s` : `${e.sets}×${e.reps} reps`} · {e.subtitle}
                </div>
              </div>
              <div style={{ fontSize: 18 }}>{e.icon}</div>
            </div>
          ))}
        </div>

        <div style={{ width: "100%", maxWidth: 380 }}>
          <button onClick={() => { setElapsed(0); startExercise(0); }} style={styles.btn}>
            EMPEZAR →
          </button>
        </div>
      </div>
    );
  }

  // DONE
  if (screen === "done") {
    return (
      <div style={{ ...styles.page, alignItems: "center", justifyContent: "center", padding: "24px", textAlign: "center" }}>
        <div style={{ fontSize: 60, marginBottom: 16 }}>✅</div>
        <h1 style={{ color: "white", fontSize: 24, fontWeight: 900, letterSpacing: 2, margin: 0 }}>
          SESIÓN COMPLETADA
        </h1>
        <div style={{ color: "#e63030", marginTop: 8, fontSize: 12, letterSpacing: 3 }}>
          {formatTime(elapsed)} · {exercises.length} ejercicios
        </div>
        <div style={{
          margin: "28px 0", padding: 18,
          background: "#111", border: "1px solid #1e1e1e",
          borderRadius: 8, maxWidth: 320, width: "100%",
        }}>
          <div style={{ color: "#444", fontSize: 10, letterSpacing: 2, marginBottom: 8 }}>RECUERDA</div>
          <div style={{ color: "#888", fontSize: 13, lineHeight: 1.7 }}>
            El <span style={{ color: "white" }}>ángel de pared</span> y el{" "}
            <span style={{ color: "white" }}>estiramiento de pecho</span> son tus ejercicios clave.
            Hazlos incluso los días de gym.
          </div>
        </div>
        <div style={{ width: "100%", maxWidth: 320 }}>
          <button onClick={() => { setElapsed(0); startExercise(0); }} style={styles.btn}>REPETIR</button>
          <button onClick={() => setScreen("home")} style={styles.btnGhost}>INICIO</button>
        </div>
      </div>
    );
  }

  // EXERCISE
  return (
    <div style={styles.page}>
      {/* Progress */}
      <div style={{ height: 3, background: "#1a1a1a" }}>
        <div style={{
          height: "100%", background: "#e63030",
          width: `${(exIdx / exercises.length) * 100}%`,
          transition: "width 0.4s ease",
        }} />
      </div>

      {/* Header */}
      <div style={{
        padding: "14px 20px", display: "flex",
        justifyContent: "space-between", alignItems: "center",
        borderBottom: "1px solid #1a1a1a",
      }}>
        <button onClick={() => { clearTimer(); setScreen("home"); }} style={{
          background: "none", border: "none", color: "#444",
          fontSize: 22, cursor: "pointer", padding: 4,
        }}>←</button>
        <div style={{ color: "#444", fontSize: 11, letterSpacing: 3 }}>
          {exIdx + 1} / {exercises.length}
        </div>
        <div style={{ color: "#333", fontSize: 11 }}>{formatTime(elapsed)}</div>
      </div>

      {/* Content */}
      <div style={{
        flex: 1, display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center", padding: "24px 20px",
      }}>
        <div style={{ fontSize: 48, marginBottom: 14 }}>{ex.icon}</div>

        <div style={{
          color: phase === "rest" ? "#888" : "#e63030",
          fontSize: 10, letterSpacing: 4, textTransform: "uppercase", marginBottom: 8,
        }}>
          {phase === "rest" ? "DESCANSO" : `SERIE ${setNum} DE ${totalSets}`}
        </div>

        <h2 style={{
          color: "white", fontSize: 22, fontWeight: 900,
          letterSpacing: 1, textAlign: "center", margin: "0 0 4px",
        }}>{ex.name}</h2>
        <div style={{ color: "#444", fontSize: 12, marginBottom: 28 }}>{ex.subtitle}</div>

        {/* Visual */}
        {((phase === "active" && ex.type === "timer") || phase === "rest") ? (
          <CircleTimer total={totalTime} remaining={timeLeft} />
        ) : (
          <div style={{
            width: 140, height: 140, borderRadius: "50%",
            border: "8px solid #1a1a1a",
            display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center",
          }}>
            {phase === "ready" ? (
              ex.type === "reps" ? (
                <>
                  <div style={{ color: "white", fontSize: 36, fontWeight: 900 }}>{ex.reps}</div>
                  <div style={{ color: "#444", fontSize: 10, letterSpacing: 2 }}>REPS</div>
                </>
              ) : (
                <>
                  <div style={{ color: "white", fontSize: 30, fontWeight: 900 }}>{ex.duration}s</div>
                  <div style={{ color: "#444", fontSize: 10, letterSpacing: 2 }}>TIMER</div>
                </>
              )
            ) : (
              <div style={{ color: "#e63030", fontSize: 36, fontWeight: 900 }}>GO</div>
            )}
          </div>
        )}

        {/* Tip */}
        {phase !== "rest" && (
          <div style={{
            marginTop: 24, padding: "14px 16px",
            background: "#111", border: "1px solid #1e1e1e",
            borderRadius: 6, maxWidth: 320, width: "100%",
          }}>
            <div style={{ color: "#333", fontSize: 10, letterSpacing: 2, marginBottom: 6 }}>💡 TÉCNICA</div>
            <div style={{ color: "#777", fontSize: 12, lineHeight: 1.7 }}>{ex.tip}</div>
          </div>
        )}
      </div>

      {/* Action */}
      <div style={{ padding: "16px 20px", borderTop: "1px solid #1a1a1a" }}>
        {phase === "ready" && (
          <button onClick={beginSet} style={styles.btn}>
            {ex.type === "timer" ? "▶ INICIAR TIMER" : "▶ EMPEZAR SERIE"}
          </button>
        )}
        {phase === "active" && ex.type === "reps" && (
          <button onClick={finishSet} style={styles.btn}>✓ SERIE COMPLETADA</button>
        )}
        {phase === "active" && ex.type === "timer" && (
          <button onClick={() => { clearTimer(); finishSet(); }} style={styles.btnGhost}>
            SALTAR
          </button>
        )}
        {phase === "rest" && (
          <button onClick={skipRest} style={styles.btnGhost}>
            SALTAR DESCANSO →
          </button>
        )}
      </div>
    </div>
  );
}
